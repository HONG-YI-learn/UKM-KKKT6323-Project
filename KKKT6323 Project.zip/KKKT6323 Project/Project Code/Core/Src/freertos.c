/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "motor.h"
#include "sensor.h"
#include "sh1106.h" 
#include "fonts.h"  
#include "cloud.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for Task_Sensor */
osThreadId_t Task_SensorHandle;
const osThreadAttr_t Task_Sensor_attributes = {
  .name = "Task_Sensor",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityRealtime,
};
/* Definitions for Task_Motor */
osThreadId_t Task_MotorHandle;
const osThreadAttr_t Task_Motor_attributes = {
  .name = "Task_Motor",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityAboveNormal,
};
/* Definitions for Task_Cloud */
osThreadId_t Task_CloudHandle;
const osThreadAttr_t Task_Cloud_attributes = {
  .name = "Task_Cloud",
  .stack_size = 2048 * 4,
  // 🚀 核心修改 1：将云端任务优先级直接拉满，保证 AT 串口收发绝对不会被抢占超时！
  .priority = (osPriority_t) osPriorityRealtime, 
};
/* Definitions for Task_UI */
osThreadId_t Task_UIHandle;
const osThreadAttr_t Task_UI_attributes = {
  .name = "Task_UI",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityBelowNormal,
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);
void vTaskSensor(void *argument);
void vTaskMotor(void *argument);
void vTaskCloud(void *argument);
void vTaskUI(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of Task_Sensor */
  Task_SensorHandle = osThreadNew(vTaskSensor, NULL, &Task_Sensor_attributes);

  /* creation of Task_Motor */
  // 🚀 核心修改 2：直接腰斩电机任务，不给它分配任何 CPU 资源
  // Task_MotorHandle = osThreadNew(vTaskMotor, NULL, &Task_Motor_attributes); 

  /* creation of Task_Cloud */
  Task_CloudHandle = osThreadNew(vTaskCloud, NULL, &Task_Cloud_attributes);

  /* creation of Task_UI */
  // 🚀 核心修改 3：直接腰斩 UI 刷新任务，彻底砍掉 OLED 对 SPI 总线的占用
  // Task_UIHandle = osThreadNew(vTaskUI, NULL, &Task_UI_attributes); 

}

/* USER CODE BEGIN Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  for(;;)
  {
    osDelay(1);
  }
}
/* USER CODE END Header_StartDefaultTask */

/* USER CODE BEGIN Header_vTaskSensor */
void vTaskSensor(void *argument)
{
  /* USER CODE BEGIN vTaskSensor */
  Sensor_InitSystem();
  uint32_t last_maintenance_tick = osKernelGetTickCount();

  /* Infinite loop */
  for(;;)
  {
      if (IMU_Sensor.isInitialized == 0) {
          IMU_Sensor.Init(&IMU_Sensor);
          osDelay(100); 
      } else {
          IMU_Sensor.ReadData(&IMU_Sensor);
          // 🚀 核心修改 4：将轮询频率从 10ms 降低到 20ms，给串口腾出更多喘息空间
          osDelay(20); 
      }

      // 🚀 核心修改 5：彻底剔除冗杂的状态机和 LED 闪烁逻辑，只做单纯的时间累加
      if ((osKernelGetTickCount() - last_maintenance_tick) >= 1000) {
          Storage_Manager.total_operating_seconds += 1;
          last_maintenance_tick = osKernelGetTickCount(); 
      }
  }
  /* USER CODE END vTaskSensor */
}

/* USER CODE BEGIN Header_vTaskMotor */
void vTaskMotor(void *argument)
{
  /* USER CODE BEGIN vTaskMotor */
  // 任务未创建，内部代码相当于死代码，无需理会
  for(;;)
  {
      osDelay(1000); 
  }
  /* USER CODE END vTaskMotor */
}

/* USER CODE BEGIN Header_vTaskCloud */
void vTaskCloud(void *argument)
{
  /* USER CODE BEGIN vTaskCloud */
  extern UART_HandleTypeDef huart2;
  extern volatile Maintenance_t Storage_Manager; 

  Cloud_Init(&huart2);

  for(;;)
  {
      Cloud_Process(Storage_Manager.temperature, Storage_Manager.vibration_intensity, Storage_Manager.total_operating_seconds);
      osDelay(10); 
  }
  /* USER CODE END vTaskCloud */
}

/* USER CODE BEGIN Header_vTaskUI */
void vTaskUI(void *argument)
{
  /* USER CODE BEGIN vTaskUI */
  // 任务未创建，内部代码相当于死代码，无需理会
  for(;;)
  {
      osDelay(1000); 
  }
  /* USER CODE END vTaskUI */
}
