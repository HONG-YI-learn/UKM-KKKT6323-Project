#ifndef __CLOUD_H
#define __CLOUD_H

#include "main.h" // 获取 HAL 库和串口定义

// 🚀 1. 把 cloud.c 里的枚举搬到这里，公开出来
typedef enum {
    CLOUD_INIT = 0,
    CLOUD_WIFI,
    CLOUD_MQTT_CFG,
    CLOUD_MQTT_CONN,
    CLOUD_READY
} CloudState_t;

// 🚀 2. 声明这是一个外部变量，其他 .c 文件可以直接读它的值
extern CloudState_t current_state;

// =======================================================
// ⚙️ ThingsBoard 与网络配置宏定义
// =======================================================
#define WIFI_SSID   "ABC"     
#define WIFI_PWD    "12345678" 
#define TB_HOST     "192.168.137.1"
#define TB_TOKEN    "local_test_user"  

// =======================================================
// 🚀 对外暴露的 API 函数
// =======================================================

// 1. 模块初始化 (依赖注入：把你的 huart2 传进来)
void Cloud_Init(UART_HandleTypeDef *huart);

// 2. 状态机心跳函数 (放在 FreeRTOS 任务里死循环跑，并把最新的数据传进去)
void Cloud_Process(float current_temp, float current_vib, uint32_t run_time);

#endif // __CLOUD_H
