#include "sensor.h"
#include "cmsis_os.h"
#include <string.h>

extern I2C_HandleTypeDef hi2c1; 

#define SENSOR_CACHE_SIZE   100
static SensorDataNode_t MemoryPool[SENSOR_CACHE_SIZE];

volatile Maintenance_t Storage_Manager = {
    .total_operating_seconds = 0,
    .vibration_intensity = 0.0f,
    .temperature = 0.0f,
    .state = MACHINE_HEALTHY
};

static void Sensor_CreateCircularList(Sensor_t* self) {
    memset(MemoryPool, 0, sizeof(MemoryPool));
    for (int i = 0; i < SENSOR_CACHE_SIZE; i++) {
        MemoryPool[i].timestamp = 0;
        if (i == 0)  MemoryPool[i].prev = &MemoryPool[SENSOR_CACHE_SIZE - 1];
        else         MemoryPool[i].prev = &MemoryPool[i - 1];
        if (i == SENSOR_CACHE_SIZE - 1) MemoryPool[i].next = &MemoryPool[0];
        else                            MemoryPool[i].next = &MemoryPool[i + 1];
    }
    self->curr = &MemoryPool[0];
}

static void IMU_Init(struct Sensor* self) {
    if (self->isInitialized) return;
    if (__HAL_I2C_GET_FLAG(&hi2c1, I2C_FLAG_BUSY) == SET || hi2c1.State != HAL_I2C_STATE_READY) {
        HAL_I2C_DeInit(&hi2c1); HAL_I2C_Init(&hi2c1); 
    }
    uint8_t who_am_i = 0;
    HAL_I2C_Mem_Read(&hi2c1, 0xD0, 0x75, 1, &who_am_i, 1, 100);
    if (who_am_i == 0x68) {
        self->isInitialized = 1; self->sampleRate = 500; 
        uint8_t wake_up_cmd = 0x00;
        HAL_I2C_Mem_Write(&hi2c1, 0xD0, 0x6B, 1, &wake_up_cmd, 1, 100);
        osDelay(50); 
    } else { self->isInitialized = 0; }
}

static void IMU_InsertNode(struct Sensor* self, float* acc, float* gyr) {
    SensorDataNode_t* next_node = self->curr->next;
    next_node->accel[0] = acc[0]; next_node->accel[1] = acc[1]; next_node->accel[2] = acc[2];
    next_node->gyro[0] = gyr[0];  next_node->gyro[1] = gyr[1];  next_node->gyro[2] = gyr[2];
    next_node->timestamp = osKernelGetTickCount(); 
    self->curr = next_node; 
}

/* ========================================================================== */
/* 虚函数实现：物理读取（电平驱动触发）                                       */
/* ========================================================================== */
static void IMU_ReadData(struct Sensor* self) {
    if (!self->isInitialized) return;
    
    if (__HAL_I2C_GET_FLAG(&hi2c1, I2C_FLAG_BUSY) == SET || hi2c1.State != HAL_I2C_STATE_READY) {
        HAL_I2C_DeInit(&hi2c1); HAL_I2C_Init(&hi2c1); self->isInitialized = 0; return;
    }
    
    uint8_t buffer[14];
    if (HAL_I2C_Mem_Read(&hi2c1, 0xD0, 0x3B, 1, buffer, 14, 100) == HAL_OK) {
        int16_t ax = (buffer[0] << 8) | buffer[1];
        int16_t ay = (buffer[2] << 8) | buffer[3];
        int16_t az = (buffer[4] << 8) | buffer[5];
        if (ax == 0 && ay == 0 && az == 0) { self->isInitialized = 0; return; }
        
        int16_t raw_temp = (buffer[6] << 8) | buffer[7];
        Storage_Manager.temperature = ((float)raw_temp / 340.0f) + 36.53f;
        
        int16_t gx = (buffer[8] << 8) | buffer[9];
        int16_t gy = (buffer[10] << 8) | buffer[11];
        int16_t gz = (buffer[12] << 8) | buffer[13];
        
        float real_acc[3] = {(float)ax / 16384.0f, (float)ay / 16384.0f, (float)az / 16384.0f};
        float real_gyr[3] = {(float)gx / 131.0f,   (float)gy / 131.0f,   (float)gz / 131.0f};
        
        float ax_prev = self->curr->accel[0];
        float diff_x = (real_acc[0] - ax_prev) > 0 ? (real_acc[0] - ax_prev) : (ax_prev - real_acc[0]);
        Storage_Manager.vibration_intensity = diff_x;
        
        // 🚀 判定震动：满足阈值直接写死低电平（点亮红灯）
        if (self->curr->timestamp != 0) {
            if (diff_x > 0.5f && Storage_Manager.total_operating_seconds < 120 && Storage_Manager.temperature <= 33.0f) {
                Storage_Manager.state = MACHINE_WARNING_VIBRATION;
                HAL_GPIO_WritePin(GPIOA, LED_Pin, GPIO_PIN_RESET); // 电平触发：强行直接砸亮红灯
            }
        }
        
        self->InsertNode(self, real_acc, real_gyr);
    } else { HAL_I2C_DeInit(&hi2c1); HAL_I2C_Init(&hi2c1); self->isInitialized = 0; }
}

/* ========================================================================== */
/* 🚀 核心边缘端维护大脑：每秒被绝对准时调用一次                              */
/* ========================================================================== */
void Maintenance_UpdateStatus(Sensor_t* sensor_obj) {
    Storage_Manager.total_operating_seconds += 1;

    // 1. 长期持续故障（超时或超温）：为了保持长期的提示性，采用闪烁形式
    if (Storage_Manager.total_operating_seconds >= 120 || Storage_Manager.temperature > 33.0f) {
        HAL_GPIO_TogglePin(GPIOA, LED_Pin); 
    } 
    // 2. 🚀 瞬时轻量故障（震动）：手停之后，由每秒绝对准时的定时器实施强制熄灭（SET）
    else if (Storage_Manager.state == MACHINE_WARNING_VIBRATION) {
        HAL_GPIO_WritePin(GPIOA, LED_Pin, GPIO_PIN_SET); // 强行拉高关灯
        Storage_Manager.state = MACHINE_HEALTHY;         // 恢复健康态
    } 
    // 3. 常态完全健康
    else {
        HAL_GPIO_WritePin(GPIOA, LED_Pin, GPIO_PIN_SET); // 确保灭灯
        Storage_Manager.state = MACHINE_HEALTHY;
    }
}

Sensor_t IMU_Sensor = { .isInitialized = 0, .sampleRate = 0, .curr = NULL, .Init = IMU_Init, .ReadData = IMU_ReadData, .InsertNode = IMU_InsertNode };

void Sensor_InitSystem(void) {
    static uint8_t network_created = 0;
    if (!network_created) { Sensor_CreateCircularList(&IMU_Sensor); network_created = 1; }
    HAL_GPIO_WritePin(GPIOA, LED_Pin, GPIO_PIN_SET);
    IMU_Sensor.Init(&IMU_Sensor);
}
