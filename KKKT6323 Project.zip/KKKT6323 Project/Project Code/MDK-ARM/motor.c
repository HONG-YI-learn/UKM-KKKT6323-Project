#include "motor.h"
#include "tim.h" // 引入 htim2 句柄

// 初始化并启动 PWM 输出
void Motor_Init(void) {
    // 启动 TIM2 通道 1 的 PWM 信号生成
    HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
    
    // 上电默认让舵机停在 0 度位置
    Motor_SetAngle(0); 
}

// 设定绝对角度控制舵机
void Motor_SetAngle(uint16_t angle) {
    // 1. 安全限幅防越界 (保护舵机不被堵转烧毁)
    if (angle > 180) {
        angle = 180;
    }
    
    // 2. 核心映射计算：
    // 0度 -> CCR=500 (0.5ms), 90度 -> CCR=1500 (1.5ms), 180度 -> CCR=2500 (2.5ms)
    // 步进系数: (2500 - 500) / 180 = 11.11
    uint16_t pulse = 500 + (angle * 2000 / 180);
    
    // 3. 写入捕获比较寄存器
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, pulse);
}

// 释放扭力急停 (关闭 PWM 信号输出，舵机会变得松软)
void Motor_Relax(void) {
    __HAL_TIM_SET_COMPARE(&htim2, TIM_CHANNEL_1, 0);
}
