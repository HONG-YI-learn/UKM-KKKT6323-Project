#ifndef __MOTOR_H
#define __MOTOR_H

#include "main.h"

/* * 舵机角度控制接口 (ES08MA-II 180度舵机)
 * 参数 angle: 目标角度 (0 - 180)
 * 警告: 前提是 TIM2 必须配置为 50Hz (周期 20ms)，ARR = 19999
 */
void Motor_Init(void);
void Motor_SetAngle(uint16_t angle);
void Motor_Relax(void); // 释放扭力 (相当于断电急停)

#endif
