#ifndef __SENSOR_H
#define __SENSOR_H

#include "main.h"      // 包含底层硬件引脚定义和基本类型
#include "cmsis_os.h"  // 极其关键：包含 FreeRTOS 系统 API，这样才能认识 osKernelGetTickCount

/* ========================================================================== */
/* 1. 预测性维护状态机枚举                             */
/* ========================================================================== */
typedef enum {
    MACHINE_HEALTHY = 0,        // 设备健康（绿灯常青或慢闪）
    MACHINE_WARNING_VIBRATION,  // 振动异常（LED 闪烁预警）
    MACHINE_WARNING_TEMP,       // 温度异常（LED 闪烁预警）
    MACHINE_WARNING_TIMEOUT     // 寿命到期（2.5分钟模拟，LED 闪烁预警）
} MachineState_t;

/* ========================================================================== */
/* 2. 高频数据缓存链表拓扑                            */
/* ========================================================================== */
typedef struct SensorDataNode {
    float accel[3];     // 加速度数据 (X, Y, Z)
    float gyro[3];      // 角速度数据 (X, Y, Z)
    uint32_t timestamp; // 数据时间戳 (记录此节点写入时的系统 Tick)
    
    struct SensorDataNode* prev; // 指向前一个节点 (历史回溯)
    struct SensorDataNode* next; // 指向后一个节点 (未来覆盖)
} SensorDataNode_t;

/* ========================================================================== */
/* 3. 硬件抽象层：Sensor 基类                          */
/* ========================================================================== */
typedef struct Sensor {
    // --- 属性 ---
    uint8_t  isInitialized; // 初始化标志位
    uint32_t sampleRate;    // 采样率 (Hz)
    
    // --- 数据缓存区 (链表核心指针) ---
    SensorDataNode_t* curr; // 始终指向最新写入的第 N 个位置
    
    // --- 虚函数表 (函数指针，实现 C 语言多态) ---
    void (*Init)(struct Sensor* self);
    void (*ReadData)(struct Sensor* self);
    void (*InsertNode)(struct Sensor* self, float* acc, float* gyr);
} Sensor_t;

/* ========================================================================== */
/* 4. 预测性维护数据包控制器                          */
/* ========================================================================== */
typedef struct {
    uint32_t total_operating_seconds; // 核心：累计运行总秒数
    float    vibration_intensity;     // 边缘端计算出的当前振动烈度
    float    temperature;             // 🚀 新增：GY87/MPU6050 内部真实摄氏度
    MachineState_t  state;            // 当前设备健康状态
} Maintenance_t;

/* ========================================================================== */
/* 5. 全局全局对象与公共接口                          */
/* ========================================================================== */
extern Sensor_t IMU_Sensor;
extern volatile Maintenance_t Storage_Manager;

void Sensor_InitSystem(void);
void Maintenance_UpdateStatus(Sensor_t* sensor_obj);

#endif /* __SENSOR_H */
