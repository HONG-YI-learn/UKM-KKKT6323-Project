#ifndef __FONTS_H
#define __FONTS_H

#include "sh1106.h" // 引入你的驱动头文件，以获取 Font_TypeDef 结构体定义

// 声明外部可用的 5x7 终端英文字体
extern const Font_TypeDef Font_5x7;

#endif // __FONTS_H
