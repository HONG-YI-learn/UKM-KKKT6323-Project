//#include "cloud.h"
//#include "cmsis_os.h" 
//#include <string.h>
//#include <stdio.h>
//#include "sensor.h"

//static UART_HandleTypeDef *cloud_uart = NULL;

//// 全局变量，供 vTaskUI 读取状态
//CloudState_t current_state = CLOUD_INIT;

//// 内部私有函数：发送 AT 指令并阻塞等待回复
//static uint8_t ESP8266_SendCmd(char* cmd, char* ack, uint32_t timeout) {
//    if (cloud_uart == NULL) return 0; 
//    
//    uint8_t rx_buf[256] = {0};
//    uint16_t rx_idx = 0;
//    uint32_t start_time = osKernelGetTickCount();
//    uint8_t ch;
//    
//    // 核心修复：强行中止并重置 HAL 库的接收状态，防死锁！
//    HAL_UART_AbortReceive(cloud_uart);
//    // 发送新指令前，暴力清除所有硬件级错误标志
//    __HAL_UART_CLEAR_OREFLAG(cloud_uart);
//    __HAL_UART_CLEAR_NEFLAG(cloud_uart);
//    __HAL_UART_CLEAR_FEFLAG(cloud_uart);
//    
//    uint32_t temp = cloud_uart->Instance->DR; 
//    (void)temp;

//    HAL_UART_Transmit(cloud_uart, (uint8_t*)cmd, strlen(cmd), 1000);

//    while(osKernelGetTickCount() - start_time < timeout) {
//        if(HAL_UART_Receive(cloud_uart, &ch, 1, 10) == HAL_OK) {
//            rx_buf[rx_idx++] = ch;
//            
//            if(rx_idx >= 254) rx_idx = 0; 
//            rx_buf[rx_idx] = '\0'; 
//            
//            if(strstr((char*)rx_buf, ack) != NULL) {
//                return 1; 
//            }
//        } else {
//            __HAL_UART_CLEAR_OREFLAG(cloud_uart);
//            osDelay(1); 
//        }
//    }
//    return 0;
//}

//// =======================================================
//// 对外暴露的 API 实现
//// =======================================================

//void Cloud_Init(UART_HandleTypeDef *huart) {
//    cloud_uart = huart; 
//    current_state = CLOUD_INIT; 
//}

//void Cloud_Process(float current_temp, float current_vib, uint32_t run_time) {
//    char tx_buf[256]; 

//    switch(current_state) {
//        case CLOUD_INIT:
//            if(ESP8266_SendCmd("AT\r\n", "OK", 1000)) {
//                ESP8266_SendCmd("AT+CWMODE=1\r\n", "OK", 1000);
//                current_state = CLOUD_WIFI;
//            } else {
//                osDelay(1000); 
//            }
//            break;

//        case CLOUD_WIFI:
//            sprintf(tx_buf, "AT+CWJAP=\"%s\",\"%s\"\r\n", WIFI_SSID, WIFI_PWD);
//            if(ESP8266_SendCmd(tx_buf, "OK", 15000)) {
//                osDelay(500); 
//                current_state = CLOUD_MQTT_CFG;
//            } else {
//                current_state = CLOUD_INIT; 
//            }
//            break;

//        case CLOUD_MQTT_CFG:
//            ESP8266_SendCmd("AT+MQTTCLEAN=0\r\n", "OK", 500); 
//            sprintf(tx_buf, "AT+MQTTUSERCFG=0,1,\"STM32_Node\",\"%s\",\"\",0,0,\"\"\r\n", TB_TOKEN);
//            if(ESP8266_SendCmd(tx_buf, "OK", 2000)) {
//                current_state = CLOUD_MQTT_CONN;
//            } else {
//                current_state = CLOUD_INIT; 
//            }
//            break;

//        case CLOUD_MQTT_CONN:
//            sprintf(tx_buf, "AT+MQTTCONN=0,\"%s\",1883,0\r\n", TB_HOST);
//            if(ESP8266_SendCmd(tx_buf, "OK", 5000)) {
//                osDelay(500); 
//                current_state = CLOUD_READY;
//            } else {
//                current_state = CLOUD_INIT; 
//            }
//            break;

//        case CLOUD_READY:
//            {  
//                // 只保留足够装下明文 JSON 的小内存，节约 RAM
//                static char json_payload[256]; 

//                // =========================================================
//                // 模式 1：对照组 (Baseline) - 纯明文极速传输
//                // 无论设备处于什么状态，只打包最轻量的明文数据
//                // =========================================================
//                sprintf(json_payload, "{\"temperature\":%.1f,\"vibration\":%.2f,\"uptime\":%u}", 
//                        current_temp, current_vib, run_time);

//                // 动态计算精准长度，告别 131 假象
//                int payload_len = strlen(json_payload);
//                sprintf(tx_buf, "AT+MQTTPUBRAW=0,\"v1/devices/me/telemetry\",%d,0,0\r\n", payload_len);

//                if(ESP8266_SendCmd(tx_buf, ">", 2000)) {
//                    if(ESP8266_SendCmd(json_payload, "OK", 3000)) {
//                        // 发送成功，这里可以打个极其轻量的桩，或者什么都不做
//                    }
//                } else {
//                    current_state = CLOUD_INIT; 
//                }

//                osDelay(10000); // 严格维持 10 秒发送间隔
//            }
//            break;
//    }
//}

//#include "cloud.h"
//#include "cmsis_os.h" 
//#include <string.h>
//#include <stdio.h>
//#include "sensor.h"

//static UART_HandleTypeDef *cloud_uart = NULL;

//// 全局变量，供 vTaskUI 读取状态
//CloudState_t current_state = CLOUD_INIT;

//// 内部私有函数：发送 AT 指令并阻塞等待回复
//static uint8_t ESP8266_SendCmd(char* cmd, char* ack, uint32_t timeout) {
//    if (cloud_uart == NULL) return 0; 
//    
//    uint8_t rx_buf[256] = {0};
//    uint16_t rx_idx = 0;
//    uint32_t start_time = osKernelGetTickCount();
//    uint8_t ch;
//    
//    // 强制复位串口接收状态，防死锁
//    HAL_UART_AbortReceive(cloud_uart);
//    __HAL_UART_CLEAR_OREFLAG(cloud_uart);
//    __HAL_UART_CLEAR_NEFLAG(cloud_uart);
//    __HAL_UART_CLEAR_FEFLAG(cloud_uart);

//    HAL_UART_Transmit(cloud_uart, (uint8_t*)cmd, strlen(cmd), 1000);

//    while(osKernelGetTickCount() - start_time < timeout) {
//        if(HAL_UART_Receive(cloud_uart, &ch, 1, 10) == HAL_OK) {
//            rx_buf[rx_idx++] = ch;
//            if(rx_idx >= 254) rx_idx = 0; 
//            rx_buf[rx_idx] = '\0'; 
//            
//            if(strstr((char*)rx_buf, ack) != NULL) {
//                return 1; 
//            }
//        } else {
//            __HAL_UART_CLEAR_OREFLAG(cloud_uart);
//            osDelay(1); 
//        }
//    }
//    return 0;
//}

//void Cloud_Init(UART_HandleTypeDef *huart) {
//    cloud_uart = huart; 
//    current_state = CLOUD_INIT; 
//}

//void Cloud_Process(float current_temp, float current_vib, uint32_t run_time) {
//    char tx_buf[256]; 

//    switch(current_state) {
//        case CLOUD_INIT:
//            if(ESP8266_SendCmd("AT\r\n", "OK", 1000)) {
//                ESP8266_SendCmd("AT+CWMODE=1\r\n", "OK", 1000);
//                current_state = CLOUD_WIFI;
//            } else {
//                osDelay(1000); 
//            }
//            break;

//        case CLOUD_WIFI:
//            sprintf(tx_buf, "AT+CWJAP=\"%s\",\"%s\"\r\n", WIFI_SSID, WIFI_PWD);
//            if(ESP8266_SendCmd(tx_buf, "OK", 15000)) {
//                osDelay(500); 
//                current_state = CLOUD_MQTT_CFG;
//            } else {
//                current_state = CLOUD_INIT; 
//            }
//            break;

//        case CLOUD_MQTT_CFG:
//            ESP8266_SendCmd("AT+MQTTCLEAN=0\r\n", "OK", 500); 
//            sprintf(tx_buf, "AT+MQTTUSERCFG=0,1,\"STM32_Node\",\"%s\",\"\",0,0,\"\"\r\n", TB_TOKEN);
//            if(ESP8266_SendCmd(tx_buf, "OK", 2000)) {
//                current_state = CLOUD_MQTT_CONN;
//            } else {
//                current_state = CLOUD_INIT; 
//            }
//            break;

//        case CLOUD_MQTT_CONN:
//            // 开启硬件级自动重连
//            sprintf(tx_buf, "AT+MQTTCONN=0,\"%s\",1883,1\r\n", TB_HOST);
//            if(ESP8266_SendCmd(tx_buf, "OK", 5000)) {
//                osDelay(500); 
//                current_state = CLOUD_READY;
//            } else {
//                current_state = CLOUD_INIT; 
//            }
//            break;

//        case CLOUD_READY:
//            {  
//                static char json_payload[256]; 

//                // =========================================================
//                // 模式 2：TLS 1.3 传输阶段模拟组 (AES-GCM 对称加密)
//                // =========================================================
//                
//                // 1. 模拟对称加密计算时间：
//                // Cortex-M4 跑 AES-128-GCM 加密极快，大约只需 5 毫秒
//                osDelay(5); 

//                // 2. 模拟密文体积膨胀：
//                // 在明文基础上，追加 16 字节的 MAC 校验码 (这里用假字符模拟)
//                sprintf(json_payload, "{\"temperature\":%.1f,\"vibration\":%.2f,\"uptime\":%u,\"tls_mac\":\"aB3x9FkQ2pL5wR8=\"}", 
//                        current_temp, current_vib, run_time);

//                // 动态计算精准长度
//                int payload_len = strlen(json_payload);
//                sprintf(tx_buf, "AT+MQTTPUBRAW=0,\"v1/devices/me/telemetry\",%d,0,0\r\n", payload_len);

//                if(ESP8266_SendCmd(tx_buf, ">", 3000)) {
//                    
//                    // 防 JSON 首字符被吞补丁
//                    osDelay(50); 

//                    if(ESP8266_SendCmd(json_payload, "OK", 5000)) {
//                        // 完美发送成功
//                    }
//                } else {
//                    current_state = CLOUD_INIT; 
//                }

//                osDelay(10000); // 严格维持 10 秒发送间隔
//            }
//            break;
//    }
//}

//#include "cloud.h"
//#include "cmsis_os.h" 
//#include <string.h>
//#include <stdio.h>
//#include "sensor.h"

//static UART_HandleTypeDef *cloud_uart = NULL;

//// 模式 3 专属：极其轻量的 Base64 编码器
//static const char base64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
//static void base64_encode(const uint8_t *in, size_t in_len, char *out) {
//    size_t i = 0, j = 0;
//    uint8_t char_array_3[3];
//    uint8_t char_array_4[4];
//    while (in_len--) {
//        char_array_3[i++] = *(in++);
//        if (i == 3) {
//            char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
//            char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
//            char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
//            char_array_4[3] = char_array_3[2] & 0x3f;
//            for(i = 0; i < 4; i++) *(out++) = base64_chars[char_array_4[i]];
//            i = 0;
//        }
//    }
//    if (i) {
//        for(j = i; j < 3; j++) char_array_3[j] = '\0';
//        char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
//        char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
//        char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
//        char_array_4[3] = char_array_3[2] & 0x3f;
//        for (j = 0; (j < i + 1); j++) *(out++) = base64_chars[char_array_4[j]];
//        while((i++ < 3)) *(out++) = '=';
//    }
//    *out = '\0';
//}

//// 全局变量，供状态机读取
//CloudState_t current_state = CLOUD_INIT;

//// 🛠️ 内部私有函数：发送 AT 指令并阻塞等待回复
//static uint8_t ESP8266_SendCmd(char* cmd, char* ack, uint32_t timeout) {
//    if (cloud_uart == NULL) return 0; 
//    
//    uint8_t rx_buf[256] = {0};
//    uint16_t rx_idx = 0;
//    uint32_t start_time = osKernelGetTickCount();
//    uint8_t ch;
//    
//    HAL_UART_AbortReceive(cloud_uart);
//    __HAL_UART_CLEAR_OREFLAG(cloud_uart);
//    __HAL_UART_CLEAR_NEFLAG(cloud_uart);
//    __HAL_UART_CLEAR_FEFLAG(cloud_uart);

//    HAL_UART_Transmit(cloud_uart, (uint8_t*)cmd, strlen(cmd), 1000);

//    while(osKernelGetTickCount() - start_time < timeout) {
//        if(HAL_UART_Receive(cloud_uart, &ch, 1, 10) == HAL_OK) {
//            rx_buf[rx_idx++] = ch;
//            if(rx_idx >= 254) rx_idx = 0; 
//            rx_buf[rx_idx] = '\0'; 
//            
//            if(strstr((char*)rx_buf, ack) != NULL) {
//                return 1; 
//            }
//        } else {
//            __HAL_UART_CLEAR_OREFLAG(cloud_uart);
//            osDelay(1); 
//        }
//    }
//    return 0;
//}

//void Cloud_Init(UART_HandleTypeDef *huart) {
//    cloud_uart = huart; 
//    current_state = CLOUD_INIT; 
//}

//void Cloud_Process(float current_temp, float current_vib, uint32_t run_time) {
//    char tx_buf[256]; 

//    switch(current_state) {
//        case CLOUD_INIT:
//            if(ESP8266_SendCmd("AT\r\n", "OK", 1000)) {
//                ESP8266_SendCmd("AT+CWMODE=1\r\n", "OK", 1000);
//                current_state = CLOUD_WIFI;
//            } else { osDelay(1000); }
//            break;

//        case CLOUD_WIFI:
//            sprintf(tx_buf, "AT+CWJAP=\"%s\",\"%s\"\r\n", WIFI_SSID, WIFI_PWD);
//            if(ESP8266_SendCmd(tx_buf, "OK", 15000)) {
//                osDelay(500); current_state = CLOUD_MQTT_CFG;
//            } else { current_state = CLOUD_INIT; }
//            break;

//        case CLOUD_MQTT_CFG:
//            ESP8266_SendCmd("AT+MQTTCLEAN=0\r\n", "OK", 500); 
//            sprintf(tx_buf, "AT+MQTTUSERCFG=0,1,\"STM32_Node\",\"%s\",\"\",0,0,\"\"\r\n", TB_TOKEN);
//            if(ESP8266_SendCmd(tx_buf, "OK", 2000)) { current_state = CLOUD_MQTT_CONN; } 
//            else { current_state = CLOUD_INIT; }
//            break;

//        case CLOUD_MQTT_CONN:
//            sprintf(tx_buf, "AT+MQTTCONN=0,\"%s\",1883,1\r\n", TB_HOST);
//            if(ESP8266_SendCmd(tx_buf, "OK", 5000)) {
//                osDelay(500); current_state = CLOUD_READY;
//            } else { current_state = CLOUD_INIT; }
//            break;

//        case CLOUD_READY:
//            {  
//                // 为 1KB 大包开辟足够的静态内存，防栈溢出
//                static char json_payload[1500]; 
//                static char base64_out[1100];
//                static uint8_t kyber_ciphertext[768];

//                // =========================================================
//                // 模式 3：ML-KEM 性能滑坡实验组
//                // =========================================================
//                
//                // 1. 模拟 PQC 矩阵运算的极其恐怖的 CPU 耗时 (约 300 毫秒)
//                osDelay(300); 

//                // 2. 模拟庞大的密文生成与 Base64 膨胀
//                memset(kyber_ciphertext, 0x88, 768); 
//                base64_encode(kyber_ciphertext, 768, base64_out);

//                // 3. 将接近 1KB 的 Base64 塞进 JSON
//                sprintf(json_payload, "{\"temperature\":%.1f,\"vibration\":%.2f,\"uptime\":%u,\"pqc_payload\":\"%s\"}", 
//                        current_temp, current_vib, run_time, base64_out);

//                // 动态计算精准长度 (此时长度应在 1100 左右)
//                int payload_len = strlen(json_payload);
//                sprintf(tx_buf, "AT+MQTTPUBRAW=0,\"v1/devices/me/telemetry\",%d,0,0\r\n", payload_len);

//                if(ESP8266_SendCmd(tx_buf, ">", 3000)) {
//                    
//                    osDelay(50); // 防吞补丁
//                    
//                    // 核心修改：等待 OK 的超时时间从 5000 拉长到 10000ms！
//                    // 因为 115200 波特率发 1KB 数据本身就要 90ms，外加极其严重的网络发送重传
//                    if(ESP8266_SendCmd(json_payload, "OK", 10000)) {
//                        // 发送成功
//                    }
//                } else {
//                    current_state = CLOUD_INIT; 
//                }

//                osDelay(10000); 
//            }
//            break;
//    }
//}

#include "cloud.h"
#include "cmsis_os.h" 
#include <string.h>
#include <stdio.h>
#include "sensor.h"

static UART_HandleTypeDef *cloud_uart = NULL;

// 极其轻量的 Base64 编码器 (用于打包 ML-KEM 庞大的密文)
static const char base64_chars[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static void base64_encode(const uint8_t *in, size_t in_len, char *out) {
    size_t i = 0, j = 0;
    uint8_t char_array_3[3];
    uint8_t char_array_4[4];
    while (in_len--) {
        char_array_3[i++] = *(in++);
        if (i == 3) {
            char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
            char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
            char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
            char_array_4[3] = char_array_3[2] & 0x3f;
            for(i = 0; i < 4; i++) *(out++) = base64_chars[char_array_4[i]];
            i = 0;
        }
    }
    if (i) {
        for(j = i; j < 3; j++) char_array_3[j] = '\0';
        char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
        char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
        char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
        char_array_4[3] = char_array_3[2] & 0x3f;
        for (j = 0; (j < i + 1); j++) *(out++) = base64_chars[char_array_4[j]];
        while((i++ < 3)) *(out++) = '=';
    }
    *out = '\0';
}

// 全局变量，供状态机读取
CloudState_t current_state = CLOUD_INIT;

// 内部私有函数：发送 AT 指令并阻塞等待回复
static uint8_t ESP8266_SendCmd(char* cmd, char* ack, uint32_t timeout) {
    if (cloud_uart == NULL) return 0; 
    
    uint8_t rx_buf[256] = {0};
    uint16_t rx_idx = 0;
    uint32_t start_time = osKernelGetTickCount();
    uint8_t ch;
    
    // 强制复位串口接收状态，防死锁
    HAL_UART_AbortReceive(cloud_uart);
    __HAL_UART_CLEAR_OREFLAG(cloud_uart);
    __HAL_UART_CLEAR_NEFLAG(cloud_uart);
    __HAL_UART_CLEAR_FEFLAG(cloud_uart);

    HAL_UART_Transmit(cloud_uart, (uint8_t*)cmd, strlen(cmd), 1000);

    while(osKernelGetTickCount() - start_time < timeout) {
        if(HAL_UART_Receive(cloud_uart, &ch, 1, 10) == HAL_OK) {
            rx_buf[rx_idx++] = ch;
            if(rx_idx >= 254) rx_idx = 0; 
            rx_buf[rx_idx] = '\0'; 
            
            if(strstr((char*)rx_buf, ack) != NULL) {
                return 1; 
            }
        } else {
            __HAL_UART_CLEAR_OREFLAG(cloud_uart);
            osDelay(1); 
        }
    }
    return 0;
}

void Cloud_Init(UART_HandleTypeDef *huart) {
    cloud_uart = huart; 
    current_state = CLOUD_INIT; 
}

void Cloud_Process(float current_temp, float current_vib, uint32_t run_time) {
    char tx_buf[256]; 

    switch(current_state) {
        case CLOUD_INIT:
            if(ESP8266_SendCmd("AT\r\n", "OK", 1000)) {
                ESP8266_SendCmd("AT+CWMODE=1\r\n", "OK", 1000);
                current_state = CLOUD_WIFI;
            } else { osDelay(1000); }
            break;

        case CLOUD_WIFI:
            sprintf(tx_buf, "AT+CWJAP=\"%s\",\"%s\"\r\n", WIFI_SSID, WIFI_PWD);
            if(ESP8266_SendCmd(tx_buf, "OK", 15000)) {
                osDelay(500); current_state = CLOUD_MQTT_CFG;
            } else { current_state = CLOUD_INIT; }
            break;

        case CLOUD_MQTT_CFG:
            ESP8266_SendCmd("AT+MQTTCLEAN=0\r\n", "OK", 500); 
            sprintf(tx_buf, "AT+MQTTUSERCFG=0,1,\"STM32_Node\",\"%s\",\"\",0,0,\"\"\r\n", TB_TOKEN);
            if(ESP8266_SendCmd(tx_buf, "OK", 2000)) { current_state = CLOUD_MQTT_CONN; } 
            else { current_state = CLOUD_INIT; }
            break;

        case CLOUD_MQTT_CONN:
            sprintf(tx_buf, "AT+MQTTCONN=0,\"%s\",1883,1\r\n", TB_HOST);
            if(ESP8266_SendCmd(tx_buf, "OK", 5000)) {
                osDelay(500); current_state = CLOUD_READY;
            } else { current_state = CLOUD_INIT; }
            break;

        case CLOUD_READY:
            {  
                // 静态内存分配，确保栈空间安全，供 1KB 大包使用
                static char json_payload[1500]; 
                static char base64_out[1100];
                static uint8_t kyber_ciphertext[768];
                
                // 核心状态机计数器：记录发送消息的次数
                static uint32_t msg_counter = 0; 
                
                int payload_len = 0;

                // =========================================================
                // 终极模式：基于事件周期驱动的混合加密架构 (Hybrid PQC)
                // =========================================================
                
                // 策略：每发送 10 次数据（第0, 10, 20次...），执行一次笨重的 ML-KEM 密钥封装
                // 其余 9 次，使用协商好的 AES 密钥进行极速对称加密传输，防止侧信道攻击
                if (msg_counter % 10 == 0) {
                    
                    /* --- 阶段一：ML-KEM 会话密钥更新 (高开销，低频) --- */
                    
                    // 1. 模拟 PQC 矩阵运算的极高 CPU 耗时 (约 300 毫秒)
                    osDelay(300); 

                    // 2. 生成庞大的密钥封装密文并 Base64 编码
                    memset(kyber_ciphertext, 0x88, 768); 
                    base64_encode(kyber_ciphertext, 768, base64_out);

                    // 3. 打包专门的“密钥轮换”包 (不包含明文遥测数据，防侧信道分析)
                    sprintf(json_payload, "{\"msg_type\":\"key_rotation\",\"pqc_payload\":\"%s\"}", base64_out);
                    
                    payload_len = strlen(json_payload);
                    sprintf(tx_buf, "AT+MQTTPUBRAW=0,\"v1/devices/me/telemetry\",%d,0,0\r\n", payload_len);

                    if(ESP8266_SendCmd(tx_buf, ">", 3000)) {
                        osDelay(50); // 防吞补丁
                        // 发送 1KB 大包，给予 10000ms 的超长容错等待时间
                        if(ESP8266_SendCmd(json_payload, "OK", 10000)) {
                            // 密钥更新成功
                        }
                    } else {
                        current_state = CLOUD_INIT; 
                    }

                } else {
                    
                    /* --- 阶段二：常规 AES-GCM 遥测传输 (低开销，高频) --- */
                    
                    // 1. 模拟对称加密计算时间：Cortex-M4 跑 AES-128 极快 (约 5 毫秒)
                    osDelay(5); 

                    // 2. 所有的震动和温度数据全部被加密隐藏 (此处用 tls_mac 模拟密文特征)
                    sprintf(json_payload, "{\"msg_type\":\"encrypted_telemetry\",\"data_len\":64,\"tls_mac\":\"aB3x9FkQ2pL5wR8=\"}");
                    
                    payload_len = strlen(json_payload);
                    sprintf(tx_buf, "AT+MQTTPUBRAW=0,\"v1/devices/me/telemetry\",%d,0,0\r\n", payload_len);

                    if(ESP8266_SendCmd(tx_buf, ">", 3000)) {
                        osDelay(50); 
                        // 发送极小的数据包，5000ms 超时足够了
                        if(ESP8266_SendCmd(json_payload, "OK", 5000)) {
                            // 极速加密传输成功
                        }
                    } else {
                        current_state = CLOUD_INIT; 
                    }
                }

                // 计数器递增，准备下一次循环
                msg_counter++;
                
                // 严格维持 10 秒发送间隔
                osDelay(10000); 
            }
            break;
    }
}
